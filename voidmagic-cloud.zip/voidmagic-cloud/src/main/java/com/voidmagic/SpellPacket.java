package com.voidmagic;

import net.minecraft.network.PacketBuffer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.fml.network.NetworkEvent;

import java.util.function.Supplier;

public class SpellPacket {
    // 0 = sky strike, 1 = catastrophe, 2 = beam start, 3 = beam stop
    public final int action;
    public SpellPacket(int action) { this.action = action; }

    public static void encode(SpellPacket msg, PacketBuffer buf) { buf.writeVarInt(msg.action); }
    public static SpellPacket decode(PacketBuffer buf) { return new SpellPacket(buf.readVarInt()); }

    public static void handle(SpellPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            if (ctx.getSender() != null) SpellLogic.handle(ctx.getSender(), msg.action);
        });
        ctx.setPacketHandled(true);
    }
}
