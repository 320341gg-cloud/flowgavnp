package com.voidmagic;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceContext;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class SpellLogic {
    private static final Map<UUID, Integer> BEAM_AGE = new ConcurrentHashMap<>();
    private static final double RANGE = 42.0D;

    private SpellLogic() {}

    public static void handle(ServerPlayerEntity player, int action) {
        if (player.world.isRemote) return;
        ServerWorld world = (ServerWorld) player.world;
        Vector3d eye = player.getEyePosition(1.0F);
        Vector3d look = player.getLook(1.0F);

        if (action == 0 || action == 1) {
            double range = action == 0 ? 48.0D : 64.0D;
            Vector3d end = eye.add(look.scale(range));
            BlockPos target = world.rayTraceBlocks(new RayTraceContext(
                    eye, end, RayTraceContext.BlockMode.COLLIDER,
                    RayTraceContext.FluidMode.NONE, player)).getPos() == null
                    ? new BlockPos(end)
                    : new BlockPos(world.rayTraceBlocks(new RayTraceContext(
                    eye, end, RayTraceContext.BlockMode.COLLIDER,
                    RayTraceContext.FluidMode.NONE, player)).getPos());

            // Sky effect: particles descend from high above the target.
            double x = target.getX() + 0.5D, z = target.getZ() + 0.5D;
            double y = Math.min(world.getHeight() - 2, target.getY() + (action == 0 ? 20 : 30));
            for (int i = 0; i < 30; i++) {
                double py = y - i * (action == 0 ? 0.65D : 1.0D);
                world.spawnParticle(ParticleTypes.PORTAL, x, py, z, 2, 0.35, 0.4, 0.35, 0.03);
                world.spawnParticle(ParticleTypes.DRAGON_BREATH, x, py, z, 1, 0.15, 0.2, 0.15, 0.01);
            }
            float radius = action == 0 ? 3.5F : 7.0F;
            float damage = action == 0 ? 12.0F : 32.0F;
            for (Entity entity : world.getEntitiesWithinAABB(Entity.class,
                    new net.minecraft.util.math.AxisAlignedBB(target).grow(radius))) {
                if (entity == player || !(entity instanceof LivingEntity)) continue;
                entity.attackEntityFrom(DamageSource.MAGIC, damage);
                if (action == 1) entity.setFire(8);
                Vector3d knock = entity.getPositionVec().subtract(target.getX() + 0.5, target.getY(), target.getZ() + 0.5)
                        .normalize().scale(action == 0 ? 0.9D : 1.8D);
                entity.addVelocity(knock.x, 0.45D, knock.z);
            }
            world.createExplosion(player, target.getX() + 0.5D, target.getY(), target.getZ() + 0.5D,
                    action == 0 ? 1.7F : 4.0F, action == 1, action == 0
                    ? net.minecraft.world.Explosion.Mode.NONE : net.minecraft.world.Explosion.Mode.BREAK);
        } else if (action == 2) {
            BEAM_AGE.put(player.getUniqueID(), 0);
        } else if (action == 3) {
            BEAM_AGE.remove(player.getUniqueID());
        }
    }

    public static void tickBeam() {
        // Tick called by the mod's server tick event; beam is continuous while the client holds LMB.
        for (Map.Entry<UUID, Integer> entry : BEAM_AGE.entrySet()) {
            UUID id = entry.getKey();
            ServerPlayerEntity player = net.minecraftforge.fml.server.ServerLifecycleHooks.getCurrentServer()
                    .getPlayerList().getPlayerByUUID(id);
            if (player == null || !player.isAlive()) { BEAM_AGE.remove(id); continue; }
            ServerWorld world = (ServerWorld) player.world;
            Vector3d start = player.getEyePosition(1.0F);
            Vector3d direction = player.getLook(1.0F);
            Vector3d end = start.add(direction.scale(RANGE));
            BlockPos hit = new BlockPos(end);
            for (int i = 1; i <= 56; i++) {
                Vector3d p = start.add(direction.scale(i * 0.75D));
                world.spawnParticle(ParticleTypes.DRAGON_BREATH, p.x, p.y, p.z, 2, 0.06, 0.06, 0.06, 0.01);
                world.spawnParticle(ParticleTypes.PORTAL, p.x, p.y, p.z, 1, 0.08, 0.08, 0.08, 0.01);
                BlockPos bp = new BlockPos(p);
                if (!world.getBlockState(bp).isAir()) { hit = bp; break; }
            }
            for (Entity entity : world.getEntitiesWithinAABB(Entity.class,
                    new net.minecraft.util.math.AxisAlignedBB(start, end).grow(0.8D))) {
                if (entity == player || !(entity instanceof LivingEntity)) continue;
                Vector3d to = entity.getPositionVec().subtract(start);
                double along = to.dotProduct(direction);
                if (along < 0 || along > RANGE) continue;
                Vector3d nearest = start.add(direction.scale(along));
                if (nearest.squareDistanceTo(entity.getPositionVec()) < 2.25D) {
                    entity.attackEntityFrom(DamageSource.MAGIC, 2.5F);
                    entity.setFire(2);
                }
            }
            // Controlled block breaking, one block per tick, restricted to ordinary breakable blocks.
            if (!world.getBlockState(hit).isAir() && !world.getBlockState(hit).getBlock().isAir(world.getBlockState(hit), world, hit)) {
                if (player.isCreative() || world.getBlockState(hit).getBlockHardness(world, hit) >= 0) {
                    world.destroyBlock(hit, false);
                }
            }
            entry.setValue(entry.getValue() + 1);
        }
    }
}
