package com.voidmagic.client;

import com.voidmagic.SpellPacket;
import com.voidmagic.VoidMagic;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = VoidMagic.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientKeys {
    public static final KeyBinding STRIKE = new KeyBinding("key.voidmagic.strike", GLFW.GLFW_KEY_Z, "key.categories.voidmagic");
    public static final KeyBinding CATASTROPHE = new KeyBinding("key.voidmagic.catastrophe", GLFW.GLFW_KEY_X, "key.categories.voidmagic");
    private static boolean beamWasHeld = false;

    private ClientKeys() {}

    public static void registerKeys() {
        ClientRegistry.registerKeyBinding(STRIKE);
        ClientRegistry.registerKeyBinding(CATASTROPHE);
    }

    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null) {
            if (beamWasHeld) VoidMagic.CHANNEL.sendToServer(new SpellPacket(3));
            beamWasHeld = false;
            return;
        }
        while (STRIKE.isPressed()) VoidMagic.CHANNEL.sendToServer(new SpellPacket(0));
        while (CATASTROPHE.isPressed()) VoidMagic.CHANNEL.sendToServer(new SpellPacket(1));

        boolean held = GLFW.glfwGetMouseButton(mc.getMainWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (held && !beamWasHeld) VoidMagic.CHANNEL.sendToServer(new SpellPacket(2));
        if (!held && beamWasHeld) VoidMagic.CHANNEL.sendToServer(new SpellPacket(3));
        beamWasHeld = held;
    }

    @SubscribeEvent
    public static void onClick(InputEvent.ClickInputEvent event) {
        if (beamWasHeld && event.isAttack()) event.setCanceled(true);
    }
}
